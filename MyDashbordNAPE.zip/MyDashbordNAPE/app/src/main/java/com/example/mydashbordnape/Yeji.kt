package com.example.mydashbordnape

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Yeji : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_yeji)
    }
}